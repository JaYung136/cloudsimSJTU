package org.sim.controller;

public class Message {
    public CODE code;
    public Object message;
}
