package org.sim.workflowsim.scheduling;

public class HEFTSchedulingAlgorithm extends BaseSchedulingAlgorithm{

    @Override
    public void run() throws Exception {

    }
}
