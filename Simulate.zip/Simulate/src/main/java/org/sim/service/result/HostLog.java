package org.sim.service.result;

public class HostLog {
    public double cpuUtilization;
    public double ramUtilization;
}
