package org.sim.controller;

public enum CODE {
    SUCCESS,
    FAILED
}
